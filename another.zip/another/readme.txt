 

**LOGIN DETAILS** 

Admin
user: admin
pass: admin123

 